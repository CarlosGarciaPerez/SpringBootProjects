package com.api.RestOpenFeing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestOpenFeingApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestOpenFeingApplication.class, args);
	}

}
