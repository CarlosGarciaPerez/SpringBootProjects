package com.api.RestOpenFeing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestOpenFeingApplicationTests {

	@Test
	void contextLoads() {
	}

}
